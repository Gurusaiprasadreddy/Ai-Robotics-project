#include <webots/robot.h>
#include <webots/motor.h>
#include <webots/distance_sensor.h>

#define TIME_STEP 64
#define MAX_SPEED 6.28

int main() {
  wb_robot_init();

  // Motors
  WbDeviceTag left_motor = wb_robot_get_device("left wheel");
  WbDeviceTag right_motor = wb_robot_get_device("right wheel");
  wb_motor_set_position(left_motor, INFINITY);
  wb_motor_set_position(right_motor, INFINITY);
  wb_motor_set_velocity(left_motor, 0.0);
  wb_motor_set_velocity(right_motor, 0.0);

  // Sonars (16 around Pioneer3dx)
  WbDeviceTag sonars[16];
  char name[4];
  for (int i = 0; i < 16; i++) {
    sprintf(name, "so%d", i);
    sonars[i] = wb_robot_get_device(name);
    wb_distance_sensor_enable(sonars[i], TIME_STEP);
  }

  while (wb_robot_step(TIME_STEP) != -1) {
    double values[16];
    for (int i = 0; i < 16; i++) {
      values[i] = wb_distance_sensor_get_value(sonars[i]);
    }

    // Front sensors: so0, so1, so15
    double front = values[0];
    if (values[1] < front) front = values[1];
    if (values[15] < front) front = values[15];

    double left_side = values[10];
    double right_side = values[5];

    // 🔧 Tuned distances (smaller = closer object)
    const double SAFE_DIST = 1200.0;
    const double CRITICAL_DIST = 800.0;

    double left_speed, right_speed;

    if (front < CRITICAL_DIST) {
      // Too close → stop and back off slightly
      left_speed = -0.3 * MAX_SPEED;
      right_speed = -0.3 * MAX_SPEED;
    } else if (front < SAFE_DIST) {
      // Start turning earlier
      if (left_side > right_side) {
        left_speed = 0.1 * MAX_SPEED;
        right_speed = 0.7 * MAX_SPEED;
      } else {
        left_speed = 0.7 * MAX_SPEED;
        right_speed = 0.1 * MAX_SPEED;
      }
    } else {
      // Path is clear → forward
      left_speed = 0.6 * MAX_SPEED;
      right_speed = 0.6 * MAX_SPEED;
    }

    wb_motor_set_velocity(left_motor, left_speed);
    wb_motor_set_velocity(right_motor, right_speed);
  }

  wb_robot_cleanup();
  return 0;
}
