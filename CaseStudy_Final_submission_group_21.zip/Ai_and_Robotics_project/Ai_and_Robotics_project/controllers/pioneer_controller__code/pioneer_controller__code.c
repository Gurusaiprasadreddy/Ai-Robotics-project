#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <webots/distance_sensor.h>
#include <webots/led.h>
#include <webots/motor.h>
#include <webots/robot.h>
#include <webots/camera.h>

#define MAX_SPEED 5.24
#define MAX_SENSOR_NUMBER 16
#define MAX_SENSOR_VALUE 1024
#define MIN_DISTANCE 1.0
#define WHEEL_WEIGHT_THRESHOLD 100

typedef struct {
  WbDeviceTag device_tag;
  double wheel_weight[2];
} SensorData;

typedef enum { FORWARD, LEFT, RIGHT } State;

static SensorData sensors[MAX_SENSOR_NUMBER] = {
  {.wheel_weight = {150, 0}}, {.wheel_weight = {200, 0}}, {.wheel_weight = {300, 0}}, {.wheel_weight = {600, 0}},
  {.wheel_weight = {0, 600}}, {.wheel_weight = {0, 300}}, {.wheel_weight = {0, 200}}, {.wheel_weight = {0, 150}},
  {.wheel_weight = {0, 0}},   {.wheel_weight = {0, 0}},   {.wheel_weight = {0, 0}},   {.wheel_weight = {0, 0}},
  {.wheel_weight = {0, 0}},   {.wheel_weight = {0, 0}},   {.wheel_weight = {0, 0}},   {.wheel_weight = {0, 0}}
};

int main() {
  wb_robot_init();
  int time_step = wb_robot_get_basic_time_step();

  WbDeviceTag left_wheel = wb_robot_get_device("left wheel");
  WbDeviceTag right_wheel = wb_robot_get_device("right wheel");

  // --- LEDs ---
  WbDeviceTag green_led = wb_robot_get_device("green led");
  WbDeviceTag red_led[3];
  red_led[0] = wb_robot_get_device("red led 1");
  red_led[1] = wb_robot_get_device("red led 2");
  red_led[2] = wb_robot_get_device("red led 3");

  // Green LED ON at start
  wb_led_set(green_led, 1);
  for(int i=0;i<3;i++) wb_led_set(red_led[i], 0);

  // --- Distance sensors ---
  char sensor_name[5] = "";
  int i;
  for (i = 0; i < MAX_SENSOR_NUMBER; ++i) {
    sprintf(sensor_name, "so%d", i);
    sensors[i].device_tag = wb_robot_get_device(sensor_name);
    wb_distance_sensor_enable(sensors[i].device_tag, time_step);
  }

  wb_motor_set_position(left_wheel, INFINITY);
  wb_motor_set_position(right_wheel, INFINITY);
  wb_motor_set_velocity(left_wheel, 0.0);
  wb_motor_set_velocity(right_wheel, 0.0);

  // --- Camera setup ---
  WbDeviceTag camera = wb_robot_get_device("camera");
  wb_camera_enable(camera, time_step);
  int width = wb_camera_get_width(camera);
  int height = wb_camera_get_height(camera);

  double speed[2] = {0.0, 0.0};
  double wheel_weight_total[2] = {0.0, 0.0};
  double distance, speed_modifier, sensor_value;
  State state = FORWARD;

  while (wb_robot_step(time_step) != -1) {
    // --- Red object detection ---
    const unsigned char *img = wb_camera_get_image(camera);
    int red_count = 0;
    for(int y=0; y<height; y+=2){
      for(int x=0; x<width; x+=2){
        int r = wb_camera_image_get_red(img, width, x, y);
        int g = wb_camera_image_get_green(img, width, x, y);
        int b = wb_camera_image_get_blue(img, width, x, y);
        if(r > 160 && r > g + 60 && r > b + 60)
          red_count++;
      }
    }
    double ratio = (double)red_count / ((width/2)*(height/2));
    if(ratio > 0.004){
      // Red detected → stop robot, switch LEDs
      wb_led_set(green_led, 0);
      for(int i=0;i<3;i++) wb_led_set(red_led[i], 1);

      wb_motor_set_velocity(left_wheel, 0.0);
      wb_motor_set_velocity(right_wheel, 0.0);
      printf("Red object detected! Robot stopped.\n");
      break;
    }

    // --- Obstacle avoidance logic ---
    memset(speed, 0, sizeof(double)*2);
    memset(wheel_weight_total, 0, sizeof(double)*2);
    for(i=0;i<MAX_SENSOR_NUMBER;i++){
      sensor_value = wb_distance_sensor_get_value(sensors[i].device_tag);
      if(sensor_value == 0.0)
        speed_modifier = 0.0;
      else{
        distance = 5.0 * (1.0 - (sensor_value / MAX_SENSOR_VALUE));
        speed_modifier = (distance < MIN_DISTANCE) ? 1 - (distance / MIN_DISTANCE) : 0.0;
      }
      for(int j=0;j<2;j++)
        wheel_weight_total[j] += sensors[i].wheel_weight[j] * speed_modifier;
    }

    switch(state){
      case FORWARD:
        if(wheel_weight_total[0] > WHEEL_WEIGHT_THRESHOLD){
          speed[0] = 0.7*MAX_SPEED; speed[1] = -0.7*MAX_SPEED; state=LEFT;
        } else if(wheel_weight_total[1] > WHEEL_WEIGHT_THRESHOLD){
          speed[0] = -0.7*MAX_SPEED; speed[1] = 0.7*MAX_SPEED; state=RIGHT;
        } else {
          speed[0] = MAX_SPEED; speed[1] = MAX_SPEED;
        }
        break;
      case LEFT:
        if(wheel_weight_total[0] > WHEEL_WEIGHT_THRESHOLD || wheel_weight_total[1] > WHEEL_WEIGHT_THRESHOLD){
          speed[0] = 0.7*MAX_SPEED; speed[1] = -0.7*MAX_SPEED;
        } else {
          speed[0] = MAX_SPEED; speed[1] = MAX_SPEED; state=FORWARD;
        }
        break;
      case RIGHT:
        if(wheel_weight_total[0] > WHEEL_WEIGHT_THRESHOLD || wheel_weight_total[1] > WHEEL_WEIGHT_THRESHOLD){
          speed[0] = -0.7*MAX_SPEED; speed[1] = 0.7*MAX_SPEED;
        } else {
          speed[0] = MAX_SPEED; speed[1] = MAX_SPEED; state=FORWARD;
        }
        break;
    }

    // --- Set motor speeds ---
    wb_motor_set_velocity(left_wheel, speed[0]);
    wb_motor_set_velocity(right_wheel, speed[1]);
  }

  wb_robot_cleanup();
  return 0;
}
