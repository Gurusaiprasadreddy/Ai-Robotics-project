/*
 * Pioneer 3-DX controller: Move in a circular motion
 */

#include <webots/robot.h>
#include <webots/motor.h>
#include <stdio.h>

#define TIME_STEP 64
#define MAX_SPEED 5.24

int main() {
  wb_robot_init();

  // Get wheels
  WbDeviceTag left_wheel = wb_robot_get_device("left wheel");
  WbDeviceTag right_wheel = wb_robot_get_device("right wheel");

  // Set infinite position (velocity control mode)
  wb_motor_set_position(left_wheel, INFINITY);
  wb_motor_set_position(right_wheel, INFINITY);

  // Set different velocities for circular motion
  double left_speed = MAX_SPEED * 0.8;   // slower wheel
  double right_speed = MAX_SPEED * 1.0;  // faster wheel

  // Main loop
  while (wb_robot_step(TIME_STEP) != -1) {
    wb_motor_set_velocity(left_wheel, left_speed);
    wb_motor_set_velocity(right_wheel, right_speed);
  }

  wb_robot_cleanup();
  return 0;
}